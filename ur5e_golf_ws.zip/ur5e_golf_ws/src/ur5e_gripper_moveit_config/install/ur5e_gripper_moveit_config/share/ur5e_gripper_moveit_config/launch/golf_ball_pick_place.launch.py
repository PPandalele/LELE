# 基于你现有的文件修复
# Copyright (c) 2021 PickNik, Inc.

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, TimerAction, RegisterEventHandler, ExecuteProcess
from launch.conditions import IfCondition
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, FindExecutable, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ur_moveit_config.launch_common import load_yaml


def generate_launch_description():
    # Declare arguments
    declared_arguments = []
    declared_arguments.append(DeclareLaunchArgument("use_sim_time", default_value="true"))
    declared_arguments.append(DeclareLaunchArgument("launch_rviz", default_value="true"))
    declared_arguments.append(DeclareLaunchArgument("description_package", default_value="ur5e_gripper_description"))
    declared_arguments.append(DeclareLaunchArgument("description_file", default_value="ur5e_gripper.urdf.xacro"))
    declared_arguments.append(DeclareLaunchArgument("moveit_config_package", default_value="ur5e_gripper_moveit_config"))

    # Initialize Arguments
    use_sim_time = LaunchConfiguration("use_sim_time")
    launch_rviz = LaunchConfiguration("launch_rviz")
    description_package = LaunchConfiguration("description_package")
    description_file = LaunchConfiguration("description_file")
    moveit_config_package = LaunchConfiguration("moveit_config_package")

    # Robot description
    robot_description_content = Command([
        PathJoinSubstitution([FindExecutable(name="xacro")]),
        " ",
        PathJoinSubstitution([FindPackageShare(description_package), "urdf", description_file]),
        " sim_gazebo:=true",
    ])
    robot_description = {"robot_description": robot_description_content}

    # Robot semantic description
    robot_description_semantic_content = Command([
        PathJoinSubstitution([FindExecutable(name="xacro")]),
        " ",
        PathJoinSubstitution([FindPackageShare(moveit_config_package), "srdf", "ur5e_gripper.srdf.xacro"]),
    ])
    robot_description_semantic = {"robot_description_semantic": robot_description_semantic_content}

    # Kinematics
    robot_description_kinematics = PathJoinSubstitution([
        FindPackageShare(moveit_config_package), "config", "kinematics.yaml"
    ])

    # Planning Configuration
    ompl_planning_pipeline_config = {
        "move_group": {
            "planning_plugin": "ompl_interface/OMPLPlanner",
            "request_adapters": "default_planner_request_adapters/AddTimeOptimalParameterization default_planner_request_adapters/FixWorkspaceBounds default_planner_request_adapters/FixStartStateBounds default_planner_request_adapters/FixStartStateCollision default_planner_request_adapters/FixStartStatePathConstraints",
            "start_state_max_bounds_error": 0.1,
        }
    }
    
    # Load OMPL planning pipeline
    ompl_planning_yaml = load_yaml("ur5e_gripper_moveit_config", "config/ompl_planning.yaml")
    ompl_planning_pipeline_config["move_group"].update(ompl_planning_yaml)

    # Controllers Configuration
    controllers_yaml = load_yaml("ur5e_gripper_moveit_config", "config/controllers.yaml")
    moveit_controllers = {
        "moveit_simple_controller_manager": controllers_yaml,
        "moveit_controller_manager": "moveit_simple_controller_manager/MoveItSimpleControllerManager",
    }

    trajectory_execution = {
        "moveit_manage_controllers": False,
        "trajectory_execution.allowed_execution_duration_scaling": 1.2,
        "trajectory_execution.allowed_goal_duration_margin": 0.5,
        "trajectory_execution.allowed_start_tolerance": 0.01,
    }

    planning_scene_monitor_parameters = {
        "publish_planning_scene": True,
        "publish_geometry_updates": True,
        "publish_state_updates": True,
        "publish_transforms_updates": True,
        "publish_robot_description": True,
        "publish_robot_description_semantic": True,
    }

    # Gazebo with custom world
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            FindPackageShare("gazebo_ros"), "/launch", "/gazebo.launch.py"
        ]),
        launch_arguments={
            "world": PathJoinSubstitution([
                FindPackageShare(moveit_config_package), "worlds", "golf_ball_word.world"
            ])
        }.items(),
    )

    # Robot State Publisher
    robot_state_publisher_node = Node(
        package="robot_state_publisher",
        executable="robot_state_publisher",
        output="both",
        parameters=[{"use_sim_time": use_sim_time}, robot_description],
    )

    # Spawn robot in Gazebo
    spawn_entity = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        arguments=["-topic", "robot_description", "-entity", "ur5e_gripper"],
        output="screen",
    )

    # Spawn golf ball
    spawn_golf_ball = Node(
        package="gazebo_ros",
        executable="spawn_entity.py",
        arguments=[
            "-entity", "golf_ball",
            "-x", "0.5", "-y", "0.4", "-z", "0.6414",  # 更保守的位置
            "-R", "0", "-P", "0", "-Y", "0",
            "-file", PathJoinSubstitution([
                FindPackageShare("ur5e_gripper_moveit_config"), 
                "urdf", 
                "golf_ball.urdf"
            ])
        ],
        output="screen",
    )
    # Joint State Broadcaster
    joint_state_broadcaster_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["joint_state_broadcaster", "--controller-manager", "/controller_manager"],
    )

    # Arm Controller
    arm_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["ur5e_arm_controller", "-c", "/controller_manager"],
    )

    # Gripper Controller
    gripper_controller_spawner = Node(
        package="controller_manager",
        executable="spawner",
        arguments=["gripper_controller", "-c", "/controller_manager"],
    )

    # MoveIt move_group node
    move_group_node = Node(
        package="moveit_ros_move_group",
        executable="move_group",
        output="screen",
        parameters=[
            robot_description,
            robot_description_semantic,
            robot_description_kinematics,
            ompl_planning_pipeline_config,
            trajectory_execution,
            moveit_controllers,
            planning_scene_monitor_parameters,
            {"use_sim_time": use_sim_time},
        ],
    )

    # RViz
    rviz_config_file = PathJoinSubstitution([
        FindPackageShare(moveit_config_package), "rviz", "view_robot.rviz"
    ])
    rviz_node = Node(
        package="rviz2",
        executable="rviz2",
        name="rviz2_moveit",
        output="log",
        arguments=["-d", rviz_config_file],
        parameters=[
            robot_description,
            robot_description_semantic,
            ompl_planning_pipeline_config,
            robot_description_kinematics,
        ],
        condition=IfCondition(launch_rviz),
    )

    # Pick and place controller
    pick_place_controller = ExecuteProcess(
        cmd=['python3', PathJoinSubstitution([
            FindPackageShare("ur5e_gripper_moveit_config"), 
            "launch", 
            "golf_ball_controller.py"
        ])],
        output="screen",
    )

    # Event handlers for proper startup sequence - 只定义一次！
    delay_move_group_after_spawn = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=spawn_entity,
            on_exit=[
                TimerAction(period=1.0, actions=[spawn_golf_ball]),  # 先生成高尔夫球
                TimerAction(period=2.0, actions=[joint_state_broadcaster_spawner]),
                TimerAction(period=4.0, actions=[arm_controller_spawner]),
                TimerAction(period=6.0, actions=[gripper_controller_spawner]),
                TimerAction(period=8.0, actions=[move_group_node]),
                TimerAction(period=10.0, actions=[rviz_node]),
                TimerAction(period=15.0, actions=[pick_place_controller]),
            ],
        )
    )

    return LaunchDescription(
        declared_arguments + [
            gazebo,
            robot_state_publisher_node,
            spawn_entity,
            delay_move_group_after_spawn,
        ]
    )