#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from moveit_msgs.action import MoveGroup
from moveit_msgs.msg import (
    MotionPlanRequest, 
    PlanningOptions,
    Constraints,
    PositionConstraint,
    OrientationConstraint,
    BoundingVolume
)
from geometry_msgs.msg import Pose, PoseStamped, Point, Quaternion
from std_msgs.msg import Header
from control_msgs.action import GripperCommand
from shape_msgs.msg import SolidPrimitive
from rclpy.action import ActionClient
from tf_transformations import quaternion_from_euler
from gazebo_msgs.srv import SetEntityState, GetEntityState
from gazebo_msgs.msg import EntityState
import math
import time
import threading


class GolfBallPickPlace(Node):
    def __init__(self):
        super().__init__('golf_ball_pick_place')
        
        # Action clients
        self.move_group_client = ActionClient(self, MoveGroup, '/move_action')
        self.gripper_client = ActionClient(self, GripperCommand, '/gripper_controller/gripper_cmd')
        
        # Gazebo服务客户端
        self.set_entity_state_client = self.create_client(SetEntityState, '/gazebo/set_entity_state')
        self.get_entity_state_client = self.create_client(GetEntityState, '/gazebo/get_entity_state')
        
        # Wait for action servers
        self.get_logger().info("Waiting for action servers...")
        if (self.move_group_client.wait_for_server(timeout_sec=15.0) and 
            self.gripper_client.wait_for_server(timeout_sec=15.0)):
            self.get_logger().info("Action servers ready!")
        else:
            self.get_logger().error("Action servers not available!")
            return
        
        # 等待Gazebo服务
        self.get_logger().info("Waiting for Gazebo services...")
        self.set_entity_state_client.wait_for_service(timeout_sec=10.0)
        self.get_entity_state_client.wait_for_service(timeout_sec=10.0)
        
        # *** 重新调整坐标 - 确保与spawn位置完全匹配 ***
        # Launch文件中spawn位置：(0.35, 0.2, 0.4214)
        # 这里的Z坐标需要考虑夹爪的接近方式
        self.pickup_pose = [0.5, 0.4, 0.65]   # 稍微高一点，让夹爪能接近球
        self.place_pose = [-0.5, -0.4, 0.65]  # 180度旋转后的位置
    
        self.gripper_tip_offset = 0.18  # 从 tool0 到夹爪指尖的偏移（单位：米）
        self.ball_radius = 0.0214       # 高尔夫球半径（单位：米）
        self.pre_grasp_offset = 0.10    # 预抓取高度偏移（单位：米）

                # 球状态跟踪
        self.ball_grasped = False
        
        # 执行任务
        self.task_completed = False
        threading.Timer(2.0, self.execute_task).start()

    def attach_ball_to_gripper(self):
        """强制将球移动到夹爪位置"""
        try:
            # 直接将球设置到pickup位置附近，模拟被抓住
            ball_state = EntityState()
            ball_state.name = "golf_ball"
            ball_state.pose.position.x = self.pickup_pose[0]
            ball_state.pose.position.y = self.pickup_pose[1]
            ball_state.pose.position.z = self.pickup_pose[2] - 0.05  # 球在夹爪下方
            ball_state.pose.orientation.w = 1.0
            
            set_request = SetEntityState.Request()
            set_request.state = ball_state
            
            future = self.set_entity_state_client.call_async(set_request)
            rclpy.spin_until_future_complete(self, future, timeout_sec=2.0)
            
            if future.result() and future.result().success:
                self.ball_grasped = True
                self.get_logger().info("Ball attached to gripper!")
                return True
                    
        except Exception as e:
            self.get_logger().error(f"Failed to attach ball: {e}")
        
        return False

    def move_ball_with_gripper(self, target_pos):
        """移动球到指定位置"""
        if not self.ball_grasped:
            return
            
        try:
            ball_state = EntityState()
            ball_state.name = "golf_ball"
            ball_state.pose.position.x = target_pos[0]
            ball_state.pose.position.y = target_pos[1]
            ball_state.pose.position.z = target_pos[2] - 0.05  # 球在夹爪下方
            ball_state.pose.orientation.w = 1.0
            
            set_request = SetEntityState.Request()
            set_request.state = ball_state
            
            self.set_entity_state_client.call_async(set_request)
                
        except Exception as e:
            pass

    def detach_ball_from_gripper(self):
        """将球放置到目标位置"""
        try:
            # 将球放置到桌面上
            ball_state = EntityState()
            ball_state.name = "golf_ball"
            ball_state.pose.position.x = self.place_pose[0]
            ball_state.pose.position.y = self.place_pose[1]
            ball_state.pose.position.z = 0.4214  # 桌面高度
            ball_state.pose.orientation.w = 1.0
            
            set_request = SetEntityState.Request()
            set_request.state = ball_state
            
            future = self.set_entity_state_client.call_async(set_request)
            rclpy.spin_until_future_complete(self, future, timeout_sec=2.0)
            
            if future.result() and future.result().success:
                self.ball_grasped = False
                self.get_logger().info("Ball placed at target position!")
                return True
                    
        except Exception as e:
            self.get_logger().error(f"Failed to detach ball: {e}")
        
        return False

    def create_target_pose(self, position, approach_angle=None):
        """创建目标姿态"""
        pose = Pose()
        pose.position = Point(x=position[0], y=position[1], z=position[2])
        
        if approach_angle is None:
            quat = quaternion_from_euler(math.pi, 0, 0)  # 夹爪向下
        else:
            quat = quaternion_from_euler(math.pi, 0, approach_angle)
            
        pose.orientation = Quaternion(x=quat[0], y=quat[1], z=quat[2], w=quat[3])
        return pose

    def move_to_pose(self, target_pose, planning_group="ur_manipulator"):
        """使用MoveIt移动到目标姿态"""
        goal_msg = MoveGroup.Goal()
        
        goal_msg.request = MotionPlanRequest()
        goal_msg.request.group_name = planning_group
        goal_msg.request.num_planning_attempts = 5
        goal_msg.request.max_velocity_scaling_factor = 0.5  # 提高速度
        goal_msg.request.max_acceleration_scaling_factor = 0.5
        goal_msg.request.allowed_planning_time = 5.0
        
        pose_stamped = PoseStamped()
        pose_stamped.header = Header()
        pose_stamped.header.frame_id = "base_link"
        pose_stamped.header.stamp = self.get_clock().now().to_msg()
        pose_stamped.pose = target_pose
        
        position_constraint = PositionConstraint()
        position_constraint.header = pose_stamped.header
        position_constraint.link_name = "tool0"
        position_constraint.target_point_offset.x = 0.0
        position_constraint.target_point_offset.y = 0.0
        position_constraint.target_point_offset.z = 0.0
        
        constraint_region = BoundingVolume()
        box = SolidPrimitive()
        box.type = SolidPrimitive.BOX
        box.dimensions = [0.03, 0.03, 0.03]  # 3cm容忍度
        constraint_region.primitives.append(box)
        constraint_region.primitive_poses.append(target_pose)
        position_constraint.constraint_region = constraint_region
        position_constraint.weight = 1.0
        
        orientation_constraint = OrientationConstraint()
        orientation_constraint.header = pose_stamped.header
        orientation_constraint.link_name = "tool0"
        orientation_constraint.orientation = target_pose.orientation
        orientation_constraint.absolute_x_axis_tolerance = 0.3
        orientation_constraint.absolute_y_axis_tolerance = 0.3
        orientation_constraint.absolute_z_axis_tolerance = 0.3
        orientation_constraint.weight = 1.0
        
        constraints = Constraints()
        constraints.position_constraints.append(position_constraint)
        constraints.orientation_constraints.append(orientation_constraint)
        goal_msg.request.goal_constraints = [constraints]
        
        goal_msg.planning_options = PlanningOptions()
        goal_msg.planning_options.plan_only = False
        goal_msg.planning_options.replan = True
        goal_msg.planning_options.replan_attempts = 3
        
        self.get_logger().info(f"Moving to: ({target_pose.position.x:.3f}, {target_pose.position.y:.3f}, {target_pose.position.z:.3f})")
        
        future = self.move_group_client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, future, timeout_sec=10.0)
        
        if not future.result():
            return False
        
        goal_handle = future.result()
        if not goal_handle.accepted:
            return False
            
        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future, timeout_sec=20.0)
        
        # 在移动过程中更新球位置
        if self.ball_grasped:
            self.move_ball_with_gripper(target_pose.position)
        
        if not result_future.result():
            return False
        
        result = result_future.result()
        if result.result.error_code.val == 1:
            self.get_logger().info("Move completed successfully")
            return True
        else:
            self.get_logger().error(f"Move failed with error code: {result.result.error_code.val}")
            return False

    def control_gripper(self, position):
        """控制夹爪"""
        goal_msg = GripperCommand.Goal()
        goal_msg.command.position = position
        goal_msg.command.max_effort = 50.0
        
        action = "Opening" if position < 0.1 else "Closing"
        self.get_logger().info(f"{action} gripper to position {position}")
        
        future = self.gripper_client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, future, timeout_sec=5.0)
        
        if not future.result():
            return False
        
        goal_handle = future.result()
        if not goal_handle.accepted:
            return False
            
        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future, timeout_sec=10.0)
        
        self.get_logger().info(f"Gripper {action.lower()} completed")
        return True

    def execute_task(self):
        """执行简化的拾取和放置任务"""
        if self.task_completed:
            return

        self.task_completed = True
        self.get_logger().info("=== Starting Simplified Golf Ball Pick and Place Task ===")
        self.get_logger().info(f"Target pickup position: {self.pickup_pose}")
        self.get_logger().info(f"Target place position: {self.place_pose}")

        try:
            # Step 1: 打开夹爪
            self.get_logger().info("Step 1: Opening gripper")
            if not self.control_gripper(0.0):
                raise Exception("Failed to open gripper")
            time.sleep(1.0)

            # Step 2: 移动到预抓取位置（球上方10cm）
            self.get_logger().info("Step 2: Moving above the golf ball")
            pre_pick_pose = self.create_target_pose([
                self.pickup_pose[0],
                self.pickup_pose[1],
                self.pickup_pose[2] + self.pre_grasp_offset
            ])
            if not self.move_to_pose(pre_pick_pose):
                raise Exception("Failed to reach pre-grasp position")
            time.sleep(1.0)

            # Step 3: 下降到抓取高度（夹爪指尖正好到球中心下方）
            self.get_logger().info("Step 3: Lowering to golf ball")
            grasp_z = self.pickup_pose[2] + self.ball_radius  # 球中心 + 球半径 = 桌面高度 + 球高
            grasp_z -= self.gripper_tip_offset                # 减去夹爪长度
            pickup_pose = self.create_target_pose([
                self.pickup_pose[0],
                self.pickup_pose[1],
                grasp_z
            ])
            if not self.move_to_pose(pickup_pose):
                raise Exception("Failed to reach pickup position")
            time.sleep(1.0)

            # Step 4: 夹住高尔夫球
            self.get_logger().info("Step 4: Closing gripper")
            if not self.control_gripper(0.3):
                raise Exception("Failed to close gripper")
            time.sleep(1.0)

            # 强制附着高尔夫球
            if self.attach_ball_to_gripper():
                self.get_logger().info("Ball forcefully attached!")
            else:
                self.get_logger().warn("Ball attachment failed, continuing anyway...")
            time.sleep(1.0)

            # Step 5: 抬升5cm
            self.get_logger().info("Step 5: Lifting golf ball slightly")
            lift_pose = self.create_target_pose([
                self.pickup_pose[0],
                self.pickup_pose[1],
                pickup_pose.position.z + 0.05
            ])
            if not self.move_to_pose(lift_pose):
                self.get_logger().warn("Failed to lift, trying direct movement to place...")
            else:
                time.sleep(1.0)

            # Step 6: 移动到放置位置上方
            self.get_logger().info("Step 6: Moving above place location")
            pre_place_pose = self.create_target_pose([
                self.place_pose[0],
                self.place_pose[1],
                self.place_pose[2] + self.pre_grasp_offset
            ])
            if not self.move_to_pose(pre_place_pose):
                raise Exception("Failed to reach place pre-position")
            time.sleep(1.0)

            # Step 7: 下降到放置高度（与抓取高度一样）
            self.get_logger().info("Step 7: Lowering to place golf ball")
            place_z = self.place_pose[2] + self.ball_radius - self.gripper_tip_offset
            place_pose = self.create_target_pose([
                self.place_pose[0],
                self.place_pose[1],
                place_z
            ])
            if not self.move_to_pose(place_pose):
                raise Exception("Failed to reach place position")
            time.sleep(1.0)

            # Step 8: 释放球
            self.get_logger().info("Step 8: Releasing golf ball")
            if self.detach_ball_from_gripper():
                self.get_logger().info("Ball successfully placed!")
            else:
                self.get_logger().warn("Ball placement failed")

            if not self.control_gripper(0.0):
                raise Exception("Failed to open gripper")
            time.sleep(1.0)

            # Step 9: 稍微抬升离开
            self.get_logger().info("Step 9: Moving away from placed ball")
            final_lift_pose = self.create_target_pose([
                self.place_pose[0],
                self.place_pose[1],
                place_z + 0.05
            ])
            if not self.move_to_pose(final_lift_pose):
                self.get_logger().warn("Failed to move away, but task completed")

            self.get_logger().info("=== GOLF BALL PICK AND PLACE COMPLETED SUCCESSFULLY! ===")
            self.get_logger().info(f"Golf ball moved from ({self.pickup_pose[0]:.2f}, {self.pickup_pose[1]:.2f}) to ({self.place_pose[0]:.2f}, {self.place_pose[1]:.2f}) - 180° rotation completed!")

        except Exception as e:
            self.get_logger().error(f"Task failed: {str(e)}")



def main(args=None):
    rclpy.init(args=args)
    
    controller = GolfBallPickPlace()
    
    try:
        rclpy.spin(controller)
    except KeyboardInterrupt:
        pass
    finally:
        controller.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()