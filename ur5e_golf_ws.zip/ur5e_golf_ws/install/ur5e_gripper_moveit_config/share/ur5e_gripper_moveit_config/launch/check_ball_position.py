#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from tf2_ros import TransformListener, Buffer
import time

class BallPositionChecker(Node):
    def __init__(self):
        super().__init__('ball_position_checker')
        
        # 创建TF2缓冲区和监听器
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        time.sleep(2)  # 等待TF数据
        self.check_ball_position()

    def check_ball_position(self):
        """使用TF检查球的位置"""
        try:
            # 获取球相对于base_link的位置
            transform = self.tf_buffer.lookup_transform(
                'base_link',  # 目标坐标系
                'golf_ball_link',  # 源坐标系（球的链接）
                rclpy.time.Time(),  # 最新时间
                timeout=rclpy.duration.Duration(seconds=5.0)
            )
            
            pos = transform.transform.translation
            self.get_logger().info(f"球相对于base_link的位置: x={pos.x:.6f}, y={pos.y:.6f}, z={pos.z:.6f}")
            self.get_logger().info(f"建议使用的坐标: [{pos.x:.6f}, {pos.y:.6f}, {pos.z:.6f}]")
            
        except Exception as e:
            self.get_logger().error(f"无法获取球的TF信息: {str(e)}")
            self.get_logger().info("请确保球的模型已加载到Gazebo中，且包含正确的TF发布")
            
            # 备用方案：根据Gazebo属性面板的信息提供建议
            self.get_logger().info("根据Gazebo属性面板，球的位置应该是:")
            self.get_logger().info("建议坐标: [0.3, -0.3, 0.441140]")
            self.get_logger().info("180度旋转后的放置坐标: [-0.3, 0.3, 0.441140]")

def main(args=None):
    rclpy.init(args=args)
    checker = BallPositionChecker()
    
    try:
        rclpy.spin_once(checker, timeout_sec=1.0)
    except KeyboardInterrupt:
        pass
    finally:
        checker.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()