#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from moveit_msgs.action import MoveGroup
from control_msgs.action import GripperCommand
from geometry_msgs.msg import Pose, PoseStamped
from moveit_msgs.msg import Constraints, PositionConstraint, OrientationConstraint
from shape_msgs.msg import SolidPrimitive
import math
import time

class TableBallController(Node):
    def __init__(self):
        super().__init__('table_ball_controller')
        
        # Action clients
        self.move_group_client = ActionClient(self, MoveGroup, '/move_action')
        self.gripper_client = ActionClient(self, GripperCommand, '/gripper_controller/gripper_cmd')
        
        # 球的位置
        self.ball_position = [0.5, 0.4, 0.1]       
        self.place_position = [-0.5, -0.4, 0.1]      
        
        # 等待action服务器
        self.get_logger().info("Waiting for action servers...")
        self.move_group_client.wait_for_server()
        self.gripper_client.wait_for_server()
        self.get_logger().info("Action servers ready!")
        
        # 开始任务
        self.execute_pick_and_place()

    # def create_pose_target(self, x, y, z):
    #     """红轴朝左不变，绿轴朝下90°，蓝轴朝后90°"""
    #     pose = Pose()
    #     pose.position.x = x
    #     pose.position.y = y
    #     pose.position.z = z
        
    #     # 绕X轴旋转90度：让Y轴从朝上变朝下，Z轴从朝前变朝后
    #     pose.orientation.w = 0.707
    #     pose.orientation.x = 0.707  # 绕X轴负向
    #     pose.orientation.y = 0.0
    #     pose.orientation.z = 0.0
        
    #     return pose
            
        
    def move_to_position(self, x, y, z, description="Moving"):
        """移动到指定位置 - 避免碰撞桌面"""
        self.get_logger().info(f"{description}")
        self.get_logger().info(f"目标位置: ({x:.3f}, {y:.3f}, {z:.3f})")
        
        goal = MoveGroup.Goal()
        goal.request.group_name = "ur_manipulator"
        goal.request.num_planning_attempts = 10
        goal.request.allowed_planning_time = 20.0
        goal.request.max_velocity_scaling_factor = 0.05
        goal.request.max_acceleration_scaling_factor = 0.05
        
        # 简单的工作空间限制 - 只限制最低高度
        goal.request.workspace_parameters.header.frame_id = "base_link"
        goal.request.workspace_parameters.header.stamp = self.get_clock().now().to_msg()
        goal.request.workspace_parameters.min_corner.x = -1.5
        goal.request.workspace_parameters.min_corner.y = -1.5
        goal.request.workspace_parameters.min_corner.z = 0.00  # 最低10cm，避免碰桌面
        goal.request.workspace_parameters.max_corner.x = 1.5
        goal.request.workspace_parameters.max_corner.y = 1.5
        goal.request.workspace_parameters.max_corner.z = 2.0
        
        # 只设置目标位置约束，不设置路径约束
        constraints = Constraints()
        
        position_constraint = PositionConstraint()
        position_constraint.header.frame_id = "base_link"
        position_constraint.header.stamp = self.get_clock().now().to_msg()
        position_constraint.link_name = "tool0"
        
        target_pose = Pose()
        target_pose.position.x = x
        target_pose.position.y = y
        target_pose.position.z = z
        target_pose.orientation.w = 1.0  # 默认姿态
        
        primitive = SolidPrimitive()
        primitive.type = SolidPrimitive.SPHERE
        primitive.dimensions = [0.05]  # 5cm容差
        
        position_constraint.constraint_region.primitives.append(primitive)
        position_constraint.constraint_region.primitive_poses.append(target_pose)
        position_constraint.weight = 1.0
        
        constraints.position_constraints.append(position_constraint)
        goal.request.goal_constraints.append(constraints)
        
        # 不设置路径约束，让MoveIt自由规划
        
        # 发送目标
        future = self.move_group_client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, future)
        
        goal_handle = future.result()
        if not goal_handle.accepted:
            return False
            
        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)
        
        result = result_future.result()
        success = result.result.error_code.val == 1
        
        if success:
            self.get_logger().info("✅ 移动成功")
        else:
            self.get_logger().error(f"❌ 移动失败")
        
        return success

    def create_position_goal_constraint(self, pose_stamped):
        """创建位置目标约束"""
        constraints = Constraints()
        
        # 位置约束
        position_constraint = PositionConstraint()
        position_constraint.header = pose_stamped.header
        position_constraint.link_name = "tool0"
        position_constraint.target_point_offset.x = 0.0
        position_constraint.target_point_offset.y = 0.0
        position_constraint.target_point_offset.z = 0.0
        
        primitive = SolidPrimitive()
        primitive.type = SolidPrimitive.BOX
        primitive.dimensions = [0.01, 0.01, 0.01]  # 1cm精度
        
        position_constraint.constraint_region.primitives.append(primitive)
        position_constraint.constraint_region.primitive_poses.append(pose_stamped.pose)
        position_constraint.weight = 1.0
        
        constraints.position_constraints.append(position_constraint)
        
        # 姿态约束 - 允许更大的姿态误差
        orientation_constraint = OrientationConstraint()
        orientation_constraint.header = pose_stamped.header
        orientation_constraint.link_name = "tool0"
        orientation_constraint.orientation = pose_stamped.pose.orientation
        orientation_constraint.absolute_x_axis_tolerance = 0.5  # 允许更大的姿态误差
        orientation_constraint.absolute_y_axis_tolerance = 0.5
        orientation_constraint.absolute_z_axis_tolerance = 0.5
        orientation_constraint.weight = 1.0
        
        constraints.orientation_constraints.append(orientation_constraint)
        
        return constraints

    def control_gripper(self, position, description="Gripper control"):
        """控制夹爪"""
        self.get_logger().info(f"{description}")
        
        goal = GripperCommand.Goal()
        goal.command.position = position
        goal.command.max_effort = 50.0
        
        future = self.gripper_client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, future)
        
        goal_handle = future.result()
        if not goal_handle.accepted:
            return False
            
        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)
        
        return True

    def execute_pick_and_place(self):
        """执行三步抓取任务"""
        self.get_logger().info("=== 三步抓取任务开始 ===")
        self.get_logger().info(f"球的位置: {self.ball_position}")
        self.get_logger().info(f"放置位置: {self.place_position}")
        
        time.sleep(5)
        
        # 步骤1: 开爪并移动到球的位置
        self.get_logger().info("步骤1: 开爪并移动到球的位置")
        self.control_gripper(0.0, "打开夹爪")
        time.sleep(3)
        
        if not self.move_to_position(
        self.ball_position[0] , 
        self.ball_position[1], 
        0.1,  # 直接到球的高度，不加0.05
        "移动到球的位置"
    ):
            self.get_logger().error("无法到达球的位置")
            return
        time.sleep(5)
        
        # 步骤2: 抓球
        self.get_logger().info("步骤2: 抓球")
        self.control_gripper(0.7, "抓取球")
        time.sleep(5)
        self.get_logger().info("🎾 球已被抓取")
        
        # 步骤3: 放置球
        self.get_logger().info("步骤3: 放置球")
        if not self.move_to_position(
            self.place_position[0], 
            self.place_position[1], 
            self.place_position[2] + 0.05,  # 放置位置上方5cm
            "移动到放置位置"
        ):
            self.get_logger().error("无法到达放置位置")
            return
        time.sleep(5)
        
        self.control_gripper(0.0, "释放球")
        time.sleep(3)
        self.get_logger().info("🎾 球已放置")
        
        # 任务完成
        self.get_logger().info("🎉 三步抓取任务完成! 🎉")

def main(args=None):
    rclpy.init(args=args)
    controller = TableBallController()
    
    try:
        rclpy.spin(controller)
    except KeyboardInterrupt:
        pass
    finally:
        controller.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()