#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from moveit_msgs.action import MoveGroup
from geometry_msgs.msg import Pose, PoseStamped
from moveit_msgs.msg import Constraints, PositionConstraint
from shape_msgs.msg import SolidPrimitive
import math

class SafeBallFinder(Node):
    def __init__(self):
        super().__init__('safe_ball_finder')
        
        # MoveIt action client
        self.move_group_client = ActionClient(self, MoveGroup, '/move_action')
        self.move_group_client.wait_for_server()
        
        self.get_logger().info("安全找球工具启动！")
        self.safe_search()

    def create_simple_pose(self, x, y, z):
        """创建简单的垂直向下姿态"""
        pose = Pose()
        pose.position.x = x
        pose.position.y = y
        pose.position.z = z
        
        # 垂直向下的简单姿态
        pose.orientation.w = 0.0
        pose.orientation.x = 1.0
        pose.orientation.y = 0.0
        pose.orientation.z = 0.0
        
        return pose

    def move_to_position(self, x, y, z, description):
        """移动到指定位置"""
        self.get_logger().info(f"{description}")
        self.get_logger().info(f"目标坐标: X={x:.2f}, Y={y:.2f}, Z={z:.2f}")
        
        goal = MoveGroup.Goal()
        goal.request.group_name = "ur_manipulator"
        goal.request.num_planning_attempts = 10  # 更多尝试次数
        goal.request.allowed_planning_time = 15.0  # 更长规划时间
        goal.request.max_velocity_scaling_factor = 0.05  # 更慢的速度
        goal.request.max_acceleration_scaling_factor = 0.05
        
        pose_stamped = PoseStamped()
        pose_stamped.header.frame_id = "base_link"
        pose_stamped.header.stamp = self.get_clock().now().to_msg()
        pose_stamped.pose = self.create_simple_pose(x, y, z)
        
        constraints = Constraints()
        position_constraint = PositionConstraint()
        position_constraint.header = pose_stamped.header
        position_constraint.link_name = "tool0"
        position_constraint.target_point_offset.x = 0.0
        position_constraint.target_point_offset.y = 0.0
        position_constraint.target_point_offset.z = 0.0
        
        primitive = SolidPrimitive()
        primitive.type = SolidPrimitive.BOX
        primitive.dimensions = [0.1, 0.1, 0.1]  # 更大的容差：10cm
        
        position_constraint.constraint_region.primitives.append(primitive)
        position_constraint.constraint_region.primitive_poses.append(pose_stamped.pose)
        position_constraint.weight = 1.0
        
        constraints.position_constraints.append(position_constraint)
        goal.request.goal_constraints.append(constraints)
        
        future = self.move_group_client.send_goal_async(goal)
        rclpy.spin_until_future_complete(self, future)
        
        goal_handle = future.result()
        if goal_handle.accepted:
            result_future = goal_handle.get_result_async()
            rclpy.spin_until_future_complete(self, result_future)
            
            result = result_future.result()
            if result.result.error_code.val == 1:
                self.get_logger().info("✅ 移动成功！")
                return True
            else:
                self.get_logger().error(f"❌ 移动失败，错误代码: {result.result.error_code.val}")
        else:
            self.get_logger().error("❌ 目标被拒绝")
        
        return False

    def safe_search(self):
        """安全搜索球的位置"""
        self.get_logger().info("开始安全搜索球的位置...")
        
        # 第1步：先移动到一个安全的高位置
        self.get_logger().info("\n=== 第1步：移动到安全高位置 ===")
        if not self.move_to_position(0.0, 0.0, 1.2, "移动到机械臂中心上方1.2米"):
            self.get_logger().error("无法到达安全位置，尝试其他位置...")
            # 尝试另一个安全位置
            if not self.move_to_position(0.2, 0.0, 1.0, "移动到另一个安全位置"):
                self.get_logger().error("无法到达任何安全位置，退出")
                return
        
        input("机械臂已移动到安全位置，按回车继续...")
        
        # 第2步：移动到球的上方较高位置
        self.get_logger().info("\n=== 第2步：移动到球上方较高位置 ===")
        ball_x = 0.3
        ball_y = -0.3
        
        if not self.move_to_position(ball_x, ball_y, 1.0, "移动到球上方1.0米"):
            self.get_logger().error("无法到达球上方，尝试调整位置...")
            # 尝试稍微不同的XY位置
            if not self.move_to_position(0.25, -0.25, 1.0, "移动到调整后的位置"):
                self.get_logger().error("无法到达球附近，退出")
                return
            else:
                ball_x = 0.25
                ball_y = -0.25
                self.get_logger().info("使用调整后的XY坐标继续")
        
        input("现在在球上方1米，按回车开始下降...")
        
        # 第3步：逐步下降，使用较大的步长
        heights_to_test = [0.8, 0.7, 0.6, 0.55, 0.5, 0.48, 0.46, 0.44, 0.42, 0.4]
        
        last_successful_height = 1.0
        
        for height in heights_to_test:
            self.get_logger().info(f"\n=== 测试高度：{height}米 ===")
            
            if self.move_to_position(ball_x, ball_y, height, f"下降到{height}米"):
                last_successful_height = height
                self.get_logger().info(f"✅ {height}米成功！")
                
                # 询问与球的距离
                print(f"\n观察Gazebo中的机械臂位置：")
                print(f"当前高度：{height}米")
                print(f"请估算末端执行器离球的距离：")
                response = input("输入距离(厘米)，或输入'close'如果很接近，或按回车继续: ")
                
                if response.strip().lower() == 'close':
                    self.get_logger().info(f"🎯 找到最佳高度：{height}米")
                    break
                elif response.strip():
                    try:
                        distance_cm = float(response)
                        self.get_logger().info(f"记录：{height}米高度，距离球{distance_cm}厘米")
                        if distance_cm <= 10:  # 10厘米以内
                            self.get_logger().info(f"🎯 找到接近位置：{height}米")
                            # 继续尝试更低的高度
                    except ValueError:
                        pass
            else:
                self.get_logger().error(f"❌ {height}米失败！")
                self.get_logger().info(f"最低可达高度：{last_successful_height}米")
                break
        
        # 总结结果
        self.get_logger().info(f"\n🎯 搜索完成！")
        self.get_logger().info(f"最终建议的球抓取坐标：")
        self.get_logger().info(f"X = {ball_x}")
        self.get_logger().info(f"Y = {ball_y}")  
        self.get_logger().info(f"Z = {last_successful_height}")
        
        # 测试放置位置（180度旋转）
        place_x = -ball_x
        place_y = -ball_y
        
        self.get_logger().info(f"\n=== 测试180度旋转的放置位置 ===")
        self.get_logger().info(f"放置位置：({place_x}, {place_y}, {last_successful_height})")
        
        if self.move_to_position(place_x, place_y, last_successful_height, "测试放置位置"):
            self.get_logger().info("✅ 放置位置也可达！")
            self.get_logger().info(f"建议的放置坐标：")
            self.get_logger().info(f"X = {place_x}")
            self.get_logger().info(f"Y = {place_y}")
            self.get_logger().info(f"Z = {last_successful_height}")
        else:
            self.get_logger().error("❌ 放置位置不可达，需要调整")

def main(args=None):
    rclpy.init(args=args)
    finder = SafeBallFinder()
    
    try:
        rclpy.spin(finder)
    except KeyboardInterrupt:
        pass
    finally:
        finder.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()